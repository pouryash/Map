//package com.example.ps.googlemap.GMap;
//
//import android.Manifest;
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.Toast;
//
//import androidx.annotation.Nullable;
//
//import com.example.ps.googlemap.R;
//import com.example.ps.googlemap.RuntimePermissionsActivity;
//import com.example.ps.googlemap.databinding.ActivityGmapBinding;
//import com.google.android.gms.common.ConnectionResult;
//import com.google.android.gms.common.GoogleApiAvailability;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.maps.SupportMapFragment;
//import com.google.android.material.snackbar.Snackbar;
//
//public class MainActivity extends RuntimePermissionsActivity {
//
//    public static final int LOCATION_REQUEST = 100;
//    private ActivityGmapBinding binding;
//    MainActivityLocationService mainActivityLocationService;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        binding = ActivityGmapBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//
//       int result = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this);
//        if (result == ConnectionResult.SUCCESS) {
//            this.requestAppPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
//                    Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
//        }else {
//            Toast.makeText(this,"service not available",Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    @Override
//    public void onPermissionsGranted(int requestCode) {
//        if (requestCode == LOCATION_REQUEST) {
//            mainActivityLocationService = new MainActivityLocationService(this);
//            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                    .findFragmentById(R.id.map);
//            mapFragment.getMapAsync(mainActivityLocationService);
//        }
//    }
//
//    @Override
//    public void onPermissionsDeny(int requestCode) {
//        if (requestCode == LOCATION_REQUEST) {
//            Snackbar.make(binding.root, "This is main activity", Snackbar.LENGTH_LONG)
//                    .setAction("retry", new View.OnClickListener() {
//                        @Override
//                        public void onClick(View view) {
//                            MainActivity.this.requestAppPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
//                                    Manifest.permission.ACCESS_FINE_LOCATION}, 100);
//                        }
//                    })
//                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
//                    .show();
//        }
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        switch (requestCode) {
//            case LocationRequest.PRIORITY_HIGH_ACCURACY:
//                switch (resultCode) {
//                    case Activity.RESULT_OK:
//                        // All required changes were successfully made
//                        Log.i("TAG", "onActivityResult: GPS Enabled by user");
//                        mainActivityLocationService.getLocation();
//                        break;
//                    case Activity.RESULT_CANCELED:
//                        // The user was asked to change settings, but chose not to
//                        Log.i("TAG", "onActivityResult: User rejected GPS request");
//
//                        break;
//                    default:
//                        break;
//                }
//                break;
//        }
//    }
//
//
//}
