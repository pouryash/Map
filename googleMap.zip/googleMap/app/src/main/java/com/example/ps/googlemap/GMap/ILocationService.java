package com.example.ps.googlemap.GMap;


//public interface ILocationService {
//
//    void addMarker(LatLng latLng, String marker);
//
//    void removeMarker();
//
//    void drawOnMap();
//
//    void changeCamera(LatLng latLng);
//
//    void getLocation();
//
//}
